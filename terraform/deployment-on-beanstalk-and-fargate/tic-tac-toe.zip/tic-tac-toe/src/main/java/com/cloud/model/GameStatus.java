package com.cloud.model;

public enum GameStatus {
    NEW, IN_PROGRESS, FINISHED
}
